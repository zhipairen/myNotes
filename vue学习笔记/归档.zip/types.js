// backend
export const LOGIN_SIGNIN = 'LOGIN_SIGNIN'
export const LOGIN_SIGNUP = 'LOGIN_SIGNUP'
export const BACK_USER_INFO = 'BACK_USER_INFO'
